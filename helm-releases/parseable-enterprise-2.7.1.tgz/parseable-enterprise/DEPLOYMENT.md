# Parseable Enterprise v2.6.6 - Helm Deployment Guide

This guide covers deploying Parseable Enterprise on Kubernetes using the `values-override.yaml` file. The deployment creates a distributed cluster with three node types: Prism (coordinator), Query (search/analytics), and Ingestor (data ingestion).

## Architecture

```
                    ┌──────────────┐
                    │    Prism     │  (1 replica)
                    │  coordinator │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │                         │
     ┌────────▼────────┐     ┌─────────▼────────┐
     │  Query (x2)     │     │  Ingestor (x3)   │
     │  search/analytics│     │  data ingestion  │
     │  + hot-tier cache│     │                  │
     └─────────────────┘     └──────────────────┘
```

## Prerequisites

- Kubernetes cluster (1.24+)
- Helm 3.x
- `kubectl` configured with cluster access
- S3-compatible object storage (AWS S3, MinIO, etc.) with a dedicated bucket
- Parseable license files (`parseable_license.json` and `parseable_license.sig`)
- A StorageClass available in the cluster (default: `standard`)

## Step 1: Create Namespace

```bash
kubectl create namespace parseable
```

## Step 2: Create Secrets

### S3 and Auth Secret

Replace all placeholder values with your actual configuration.

```bash
kubectl create secret generic parseable-env-secret \
  --from-literal=addr=0.0.0.0:8000 \
  --from-literal=username=<admin-username> \
  --from-literal=password=<admin-password> \
  --from-literal=staging.dir=/parseable/staging \
  --from-literal=s3.url=<s3-endpoint-url> \
  --from-literal=s3.access.key=<s3-access-key> \
  --from-literal=s3.secret.key=<s3-secret-key> \
  --from-literal=s3.bucket=<s3-bucket-name> \
  --from-literal=s3.region=<s3-region> \
  -n parseable
```

**S3 URL examples:**
- AWS S3: `https://s3.<region>.amazonaws.com`
- MinIO: `http://minio.minio.svc.cluster.local:9000`

### License Secret

```bash
kubectl create secret generic parseable-license \
  --from-file=parseable_license.json=<path>/parseable_license.json \
  --from-file=parseable_license.sig=<path>/parseable_license.sig \
  -n parseable
```

## Step 3: Configure values-override.yaml

Edit `values-override.yaml` before deploying:

### Cluster Secret

Set `P_CLUSTER_SECRET` to the same 16-character alphanumeric string in all three places (ingestor, prism, querier). This secret authenticates nodes in the cluster.

```bash
# Generate a cluster secret
head /dev/urandom | LC_ALL=C tr -dc A-Za-z0-9 | head -c 16; echo
```

Update the value in `values-override.yaml` under:
- `parseable.highAvailability.ingestor.env.P_CLUSTER_SECRET`
- `parseable.prism.env.P_CLUSTER_SECRET`
- `parseable.env.P_CLUSTER_SECRET`

### Storage Class

Update `storageClass` under `parseable.persistence` for your cluster. Common values:
- GKE: `standard`, `premium-rwo`
- EKS: `gp2`, `gp3`
- AKS: `managed-premium`, `default`

### Resources

Default resource allocations (adjust based on workload):

| Component | CPU req/limit | Memory req/limit |
|-----------|--------------|-----------------|
| Ingestor  | 1 / 2        | 2Gi / 4Gi      |
| Querier   | 1 / 2        | 2Gi / 4Gi      |
| Prism     | 500m / 1     | 1Gi / 2Gi      |

### Persistence Volumes

| Component | Volume         | Default Size |
|-----------|---------------|-------------|
| Ingestor  | staging       | 100Gi       |
| Querier   | hot-tier      | 5Ti         |
| Prism     | staging       | 50Gi        |

## Step 4: Deploy

```bash
helm install parseable . \
  -f values-override.yaml \
  -n parseable
```

### Verify Deployment

```bash
# Check all pods are running
kubectl get pods -n parseable

# Expected output (wait 2-3 minutes for all pods to be Ready):
# parseable-prism-0       1/1   Running
# parseable-querier-0     1/1   Running
# parseable-querier-1     1/1   Running
# parseable-ingestor-0    1/1   Running
# parseable-ingestor-1    1/1   Running
# parseable-ingestor-2    1/1   Running

# Check services
kubectl get svc -n parseable

# Check PVCs
kubectl get pvc -n parseable
```

### Startup Order

The chart handles startup ordering automatically:
1. **Prism** starts first
2. **Querier** and **Ingestor** pods have init containers that wait for Prism to be ready before starting

## Step 5: Access the Dashboard

Port-forward the Prism service to access the UI:

```bash
kubectl port-forward svc/parseable-prism-service 8000:80 -n parseable
```

Open `http://localhost:8000` and login with the admin credentials set in the secret.

## Upgrade

```bash
helm upgrade parseable . \
  -f values-override.yaml \
  -n parseable
```

## Uninstall

```bash
helm uninstall parseable -n parseable
```

> **Note:** PVCs are not deleted on uninstall. Delete them manually if needed:
> ```bash
> kubectl delete pvc -l app=parseable -n parseable
> ```

## Sending Data

Point log shippers (OTel Collector, Fluent Bit, Vector, etc.) to the ingestor service:

```
http://parseable-ingestor-service.parseable.svc.cluster.local/api/v1/ingest
```

Use basic auth with the admin credentials configured in the secret.

## Troubleshooting

```bash
# Check pod logs
kubectl logs parseable-prism-0 -n parseable
kubectl logs parseable-querier-0 -n parseable
kubectl logs parseable-ingestor-0 -n parseable

# Check events
kubectl get events -n parseable --sort-by='.lastTimestamp'

# Describe a pod for scheduling issues
kubectl describe pod parseable-prism-0 -n parseable
```

Common issues:
- **Pods stuck in Init**: Prism is not ready yet. Check prism pod logs.
- **CrashLoopBackOff**: Verify secrets exist and values are correct. Check `P_CLUSTER_SECRET` is identical across all nodes.
- **PVC Pending**: Verify StorageClass exists and has available capacity.
